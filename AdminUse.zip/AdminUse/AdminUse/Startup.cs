﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AdminUse.Startup))]
namespace AdminUse
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
