﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SmartDevice.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Smart Device for Energy Consumption Awareness in Household";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "We are-";

            return View();
        }
    }
}